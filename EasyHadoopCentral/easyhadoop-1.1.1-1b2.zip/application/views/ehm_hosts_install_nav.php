	<div class="span2">
		<div class="">
			<a href="<?php echo $this->config->base_url();?>index.php/install/index/" class="btn btn-info"><i class="icon-random"></i> 安装hadoop </a>
		</div>
	</div>