<div class="span2">
	<div class="">
			<a href="<?php echo $this->config->base_url();?>index.php/settings/index" class="btn btn-info">Hadoop配置</a>
	</div>
</div>