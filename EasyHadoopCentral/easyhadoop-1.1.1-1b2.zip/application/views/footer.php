<hr></hr>
<center>CopyRight Xianglei 2012-2013 Under GPLv3  License, Don't Remove this line, Runtime: <?php echo $this->benchmark->elapsed_time();?><br /></center>
	</body>
</html>