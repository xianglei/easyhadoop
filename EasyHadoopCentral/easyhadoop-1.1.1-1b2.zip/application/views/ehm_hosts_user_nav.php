<div class="span2">
	<div class="">
			<a href="<?php echo $this->config->base_url();?>index.php/user/updatepassword/" class="btn btn-info"><i class="icon-thumbs-up"></i>用户操作</a>
	</div>
</div>