<div class="span2">
	<div class="btn-group btn-group-vertical">
			<a href="<?php echo $this->config->base_url();?>index.php/operate/index/" class="btn btn-info"><i class="icon-thumbs-up"></i>Hadoop操作</a>
			<a href="<?php echo $this->config->base_url();?>index.php/operate/job/" class="btn btn-info"><i class="icon-tasks"></i>Job操作</a>
	</div>
</div>