<div class="span10">
<pre>
Architecture Designing : Slaytanic <br />
Programmer : Slaytanic <br />
UI and frontend : Slaytanic <br /><br />

Using language and frameworks : jQuery, Bootstrap(Twitter), CodeIginter(php), Python, Shell.
</pre>
</div>