<div id="push_rackaware" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-header">
		<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
		<h3 id="myModalLabel">推送机架感知</h3>
	</div>
	<div class="modal-body">

			<div id="push_rackaware_status"></div>

	</div>
	<div class="modal-footer">
		<button class="btn" data-dismiss="modal">Close</button>
		<button class="btn btn-danger" onclick="push_rackaware_status()"><?php echo $common_submit;?></button>
	</div>
</div>