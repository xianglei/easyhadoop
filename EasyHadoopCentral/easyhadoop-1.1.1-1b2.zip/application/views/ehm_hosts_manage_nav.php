<div class="span2">
	<div class="">
			<a href="#add_hadoop_node"  role="button" data-toggle="modal" class="btn btn-info"><?php echo $common_add_node;?></a>
	</div>
</div>