<?php
$lang['success_change_password'] = '密码变更完成';
$lang['success_add_user'] = '添加用户成功';