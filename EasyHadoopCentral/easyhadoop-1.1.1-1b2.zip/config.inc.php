<?php

#this is user definable area
#这里是用户定义区域

$configure['language'] = 'chinese';

$configure['packages_source_address'] = '113.11.199.230';

?>